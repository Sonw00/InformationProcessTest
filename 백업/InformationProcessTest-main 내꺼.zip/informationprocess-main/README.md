Not Updated
loginId = loginId+(totalTime, score) 

Updated
2023_1_3,4,5  -240730
