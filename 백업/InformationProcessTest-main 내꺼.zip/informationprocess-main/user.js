
const User = {
    "items": [
        {
            "id": "thsdndud111",
            "pwd": "thsdndud1",
            "name": "손우영",
            "birthDate": "980919",
            "email": "thsdndud121@naver.com"
        },
        {
            "id": "wjswlsvy000",
            "pwd": "wjswlsvy0",
            "name": "전진표",
            "birthDate": "680715",
            "email": "wjswlsvy@google.com"
        },
        {
            "id": "1",
            "pwd": "1",
            "name": "1",
            "birthDate": "1",
            "email": "1"
        },
        {
            "id": "ghdwnsvy13",
            "pwd": "ghdwnsvy9",
            "name": "공준표",
            "birthDate": "240722",
            "email": "kongjunp@nate.com"
        }
    ]
};